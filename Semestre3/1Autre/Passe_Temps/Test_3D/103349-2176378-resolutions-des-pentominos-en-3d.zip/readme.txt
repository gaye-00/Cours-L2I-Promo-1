Résolutions des pentominos en 3D--------------------------------
Url     : http://codes-sources.commentcamarche.net/source/103349-resolutions-des-pentominos-en-3dAuteur  : pabbatiDate    : 10/01/2022
Licence :
=========

Ce document intitul� � Résolutions des pentominos en 3D � issu de CommentCaMarche
(codes-sources.commentcamarche.net) est mis � disposition sous les termes de
la licence Creative Commons. Vous pouvez copier, modifier des copies de cette
source, dans les conditions fix�es par la licence, tant que cette note
appara�t clairement.

Description :
=============

2 versions en c++ et des fichiers html
